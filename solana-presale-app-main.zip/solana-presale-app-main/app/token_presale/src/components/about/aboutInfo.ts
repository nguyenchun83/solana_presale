const aboutInfo = [
    {
        id: 0,
        title: "Discover",
        description: 'Discover upcoming presales to get in early!',
        link: '/discover'
    },
    {
        id: 1,
        title: "Create",
        description: 'Create your own presale and get the funding you need!',
        link: '/create'
    },
    
  
]
export default aboutInfo;