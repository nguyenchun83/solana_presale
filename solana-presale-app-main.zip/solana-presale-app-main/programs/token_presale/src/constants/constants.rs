use anchor_lang::prelude::*;

#[constant]
pub const PRESALE_SEED: &[u8] = b"PRESALE_SEED";
pub const WALLET_SEED: &[u8] = b"WALLET_SEED";