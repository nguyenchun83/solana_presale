import { PublicKey } from "@solana/web3.js";

export const PRESALE_PROGRAM_PUBKEY = new PublicKey("ehzTTCgmtXwK1GyHZRRnte4Rdt1yTvrvG635M76RPfm");
// Change later
export const BONK_TOKEN_PUBKEY = new PublicKey("ehzTTCgmtXwK1GyHZRRnte4Rdt1yTvrvG635M76RPfm");
export const WALLET_SEED = "WALLET_SEED";
export const PRESALE_SEED = "PRESALE_SEED";
export const NETWORK = "devnet";