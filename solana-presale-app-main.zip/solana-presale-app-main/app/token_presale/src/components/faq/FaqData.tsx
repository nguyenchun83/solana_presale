const FaqData = [
    {
        id: 1,
        question: "What is BuildABonk?",
        answer: "BuildABonk aims to cater to all your token creation and buying needs. Allowing you to make the token of your dreams, without the hassle of CLIs and coding. Or do you just want to get an early entry into the next big thing? We've got you covered!"
    },
    {
        id: 2,
        question: "Why should I use BuildABonk?",
        answer: "BuildABonk is the easiest way to create and buy presale tokens. We have a simple and intuitive interface, and are constantly improving our product."
    },
    {
        id: 3,
        question: "What are the fees?",
        answer: "There is a 5% fee on all transactions. 100% of the proceeds are burned!"
    },
    {
        id: 4,
        question: "Is the project open source?",
        answer: "Yes! The project is open source, and you can find the code on our github page."
    },
    {
        id: 5,
        question: "BONK?",
        answer: "BONK!"
    },
    
]
export default FaqData;