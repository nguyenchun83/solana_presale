# solana-presale-app
A website for creating cryptocurrencies on the Solana blockchain and hosting presales

Languages used - Typescript, Javascript, Rust_Language, HTML, CSS

Libraries used - TailwindCSS, React.js, Next.js, Anchor_Lang

https://buildabonk.com/
